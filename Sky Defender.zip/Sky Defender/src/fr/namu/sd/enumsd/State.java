package fr.namu.sd.enumsd;

public enum State {
	VIVANT, MORT, SPEC
}

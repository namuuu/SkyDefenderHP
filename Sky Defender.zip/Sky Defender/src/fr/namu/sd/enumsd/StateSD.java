package fr.namu.sd.enumsd;

public enum StateSD {
	LOBBY, TELEPORTATION, GAME, FIN
}
